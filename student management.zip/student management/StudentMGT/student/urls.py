from django.urls import path,include
from student import views

urlpatterns = [
    path('login/',views.login,name='login'),
    path('registration/',views.reg,name='reg'),
    path('display',views.display,name='display'),
    path('branch',views.branch,name='branch'),
]
