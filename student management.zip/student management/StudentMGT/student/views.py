from sre_constants import BRANCH
from django.shortcuts import redirect, render
from datetime import datetime
from student.models import Branch
from student.models import Student
from django.template import RequestContext

# Create your views here.

def reg(request):
    if request.method=="POST":
        sname=request.POST.get('name')
        semail=request.POST.get('email')
        smob=request.POST.get('mob')
        spwd=request.POST.get('pwd')
        std=Student(name=sname,email=semail,mob=smob,pwd=spwd,date=datetime.today())
        std.save()
    return render(request,'student/registration.html')
    
def display(request):
    sdata=Student.objects.all()
    print(sdata)
    sdata1={"sdt":sdata}
    return render(request,'student/display.html',sdata1)

def login(request):
    print("Hello USERLOGIN")
    if request.method == "POST":
        email= request.POST.get('email')
        pwd = request.POST.get('pwd')
   
        res = Student.objects.filter(email=email,pwd=pwd).exists()
        print("CHECK ",res)#BOOL VALUE
        if res:
            return render(request,'student/afterlogin.html')
        else:
            return redirect('student/login')

    return render(request,'student/login.html')

def branch(request):
    bdata=Branch.objects.all()
    print(bdata)
    bdata1={"bdt":bdata}
    return render(request,'student/branch.html',bdata1)