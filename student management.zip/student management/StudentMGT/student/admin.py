from django.contrib import admin
from student.models import Student
from student.models import Degree
from student.models import Branch
from student.models import Subject
from student.models import Faculty
from student.models import Subfact
from student.models import Notes
 
# Register your models here.
admin.site.register(Student)
admin.site.register(Degree)
admin.site.register(Branch)
admin.site.register(Subject)
admin.site.register(Faculty)
admin.site.register(Subfact)
admin.site.register(Notes)

