from django.db import models

# Create your models here.


class Degree(models.Model):
    id=models.IntegerField("Degree Name",primary_key=True)        
    dname=models.CharField(max_length=50)
    dyear=models.IntegerField()
    dtype=models.CharField(max_length=50)
    ddesc=models.CharField(max_length=50)

    def __str__(self):
        return self.dname

class Branch(models.Model):
    did=models.ForeignKey(Degree, on_delete=models.CASCADE) 
    bid=models.IntegerField(primary_key=True)   
    bname=models.CharField(max_length=50)
    bdesc=models.CharField(max_length=50)

    def __str__(self):
        return self.bname

class Subject(models.Model):
    bid=models.ForeignKey(Branch, on_delete=models.CASCADE) 
    sid=models.IntegerField(primary_key=True)   
    sname=models.CharField(max_length=50)
    stype=models.CharField(max_length=50)
    syllabus=models.CharField(max_length=50)

    def __str__(self):
        return self.sname

class Faculty(models.Model):
    bid=models.ForeignKey(Branch, on_delete=models.CASCADE) 
    fid=models.IntegerField(primary_key=True)   
    fname=models.CharField(max_length=50)

    def __str__(self):
        return self.fname


class Subfact(models.Model):
    sid=models.ForeignKey(Subject, on_delete=models.CASCADE) 
    sfid=models.IntegerField(primary_key=True)
    fid=models.ForeignKey(Degree, on_delete=models.CASCADE)
    sdate=models.CharField(max_length=100)  

    def __str__(self):
        return self.sid   

class Notes(models.Model):
    sid=models.ForeignKey(Subject, on_delete=models.CASCADE) 
    fid=models.ForeignKey(Faculty, on_delete=models.CASCADE)
    nid=models.ForeignKey(Degree, on_delete=models.CASCADE) 
    udate=models.CharField(max_length=100) 
    uploadnotes = models.CharField(max_length=1000) 

    def __str__(self):
        return self.nid  

class Student(models.Model):
    name=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    mob=models.CharField(max_length=100)
    pwd=models.CharField(max_length=5)
    date=models.CharField(max_length=100)   
    #mobiddels.ForeignKey(Branch,on_delete=models.CASCADE)
    def __str__(self):
        return self.name